﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.OleDb;

using Dal;
using Entity;

namespace Bll
{
    public class bll
    {
        public Account check_login_info(String account, String password, int flag)
        {
            String table_name = "";
            switch (flag)
            {
                case 0:
                    table_name = "Student";
                    break;
                case 1:
                    table_name = "Teacher";
                    break;
                case 2:
                    table_name = "Administrator";
                    break;
                default:
                    break;
            }

            String selectAccountInfo_str = "select Stuff.* " + "from Stuff," + table_name + " where " +
                        "Stuff.Account='" + account +
                        "' and Stuff.Password='" + password +
                        "' and Stuff.Stuff_Id = " + table_name + ".Stuff_Id ";

            dal a = new dal();
           
            Account info_account = a.sql_Query(selectAccountInfo_str);            

            return info_account;
        }

        public bool change_password(String stuff_id, String new_password)
        {
            bool if_success = false;

            String updateAccountInfo_str = "update Stuff set password='" + new_password + "' where Stuff_Id='" + stuff_id + "'";

            dal a = new dal();

            if_success = a.sql_update_AccountInfo(updateAccountInfo_str, new_password);

            return if_success;
        }

        public bool add_student(String student_id, String course_id)
        {
            bool if_success = false;

            String sql = "insert into Student_list values('" + student_id + "','" + course_id + "')";

            dal a = new dal();

            if_success = a.sql_add_Student(sql);

            return if_success;
        }

        public bool add_homework(String homework_id , String content, String date,
                                 String course_id, String teacher_id)
        {
            bool if_success = false;

            String sql = "insert into Homework values('" + homework_id + "','" + content
                         + "','" + date + "','" + course_id + "','" + teacher_id + "')";

            dal a = new dal();

            if_success = a.sql_add_Homework(sql);

            return if_success;
        }

        public List<Inform> get_Inform()
        {
            String sql = "select * from Inform";

            dal a = new dal();
            return a.sql_get_Inform(sql);
        }

        public List<Course> get_Course(String student_id)
        {
            String sql = "select * from Course where Course_Id=" +
                        "(select Course_Id from Student_list where Student_Id='" + student_id + "')";

            dal a = new dal();
            return a.sql_get_Course(sql);
        }             

        public List<Examination> get_Exam(String student_id)
        {
            String sql = "select * from Examination where Student_Id='" + student_id + "'";

            dal a = new dal();
            return a.sql_get_Exam(sql);
        }

        public List<Homework> get_Homework(String student_id)
        {
            String sql = "select * from Homework,Student_list where Student_Id='" +
                        student_id + "'" + "and Student_list.Course_Id=Homework.Course_Id";
            dal a = new dal();
            return a.sql_get_Homework(sql);
        }

        public bool insert_Inform(String info_id, String type, 
                                  String title, String content, String stuff_id)
        {
            bool if_success = false;
            String date = DateTime.Today.Date.ToString();
            String sql = "insert into Inform values('" + info_id +"','"+ title +
                                    "','" + content + "','" + type + "','" +
                                    date + "','" + stuff_id + "')";
            dal a = new dal();
            if_success = a.sql_insert_Inform(sql);

            return if_success;
        }
    }
}
