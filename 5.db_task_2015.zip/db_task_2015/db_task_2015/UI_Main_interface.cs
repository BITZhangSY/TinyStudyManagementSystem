﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace db_task_2015
{
    public partial class UI_Main_interface : Form
    {
        String stuff_id;
        String account;
        String password;
        String name;
        String type;       
        int flag;   
        public UI_Main_interface(String stuff_id, String account, String password, 
                                 String name, String type, int flag)
        {
            InitializeComponent();
            this.stuff_id = stuff_id;
            this.account = account;
            this.password = password;
            this.name = name;
            this.type = type;
            this.flag = flag;
        }

        private void UI_Main_interface_Load(object sender, EventArgs e)
        {
            this.account_label.Text = account;
            this.name_label.Text = name;
            this.type_label.Text = type;

            init_interface(flag);

            
        }

        private void init_interface(int flag)
        {
            this.tab_bt_1.Text = "通知";
            this.tab_bt_5.Text = "个人信息";
            this.quit_bt.Text = "退出";

            if (flag == 2)       //若是管理员
            {
                this.tab_bt_6.Visible = false;
                this.tab_bt_3.Visible = false;
                this.tab_bt_4.Visible = false;

                this.tab_bt_2.Text = "管理账户";
            }
            else if(flag == 1)
            {
                this.tab_bt_6.Visible = false;
                this.tab_bt_4.Visible = false;
                this.tab_bt_2.Text = "管理课程";
                this.tab_bt_3.Text = "管理考试";
                //this.tab_bt_4.Text = "成绩测评";
            }
            else
            {
                this.tab_bt_2.Text = "课表";
                this.tab_bt_3.Text = "考试";
                this.tab_bt_4.Text = "成绩";
                this.tab_bt_6.Text = "作业";
            }
        }

        private void tab_bt_5_Click(object sender, EventArgs e)
        {
            UI_PersonalCenter personal_center = new UI_PersonalCenter(stuff_id, account,
                                                    password, name, type);
            personal_center.Show();
        }

        private void quit_bt_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tab_bt_2_Click(object sender, EventArgs e)
        {
            if(2 == flag)   //若是管理员则tab2为管理账户
            {
                UI_Account_Management personal_center = new UI_Account_Management();
                personal_center.Show();
               
            }else if(1 == flag)      //若是教师则tab2为管理课程  
            {
                UI_CommonWindow_ForTeacher common_window = new UI_CommonWindow_ForTeacher(stuff_id);
                common_window.Show();
            }
            else              //若为学生则为查看课表      
            {
                show_CommonWin_ForStu(2);
            }
        }

        private void tab_bt_1_Click(object sender, EventArgs e)
        {
            //bool is_student = flag == 0 ? true : false;
            UI_InformCenter inform_center = new UI_InformCenter(stuff_id);
            inform_center.Show();
        }

        private void tab_bt_3_Click(object sender, EventArgs e)
        {
            if(1 == flag)
            {
                UI_Test_ForTeacher test_forTeacher = new UI_Test_ForTeacher();
                test_forTeacher.Show();
            }
            else
            {
                show_CommonWin_ForStu(3);                
            }
        }

        private void tab_bt_4_Click(object sender, EventArgs e)
        {
            show_CommonWin_ForStu(4);
        }

        private void tab_bt_6_Click(object sender, EventArgs e)
        {
            show_CommonWin_ForStu(5);
        }

        private void show_CommonWin_ForStu(int flag)
        {
            UI_CommonWindow_ForStudent common_window = new UI_CommonWindow_ForStudent(flag, stuff_id);
            common_window.Show();
        }
    }
}
