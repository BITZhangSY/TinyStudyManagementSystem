﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace db_task_2015
{
    public partial class UI_Test_ForTeacher : Form
    {
        public UI_Test_ForTeacher()
        {
            InitializeComponent();
        }

        private void UI_Test_ForTeacher_Load(object sender, EventArgs e)
        {
            this.adapter.Fill(this.dataSet1);

            this.label1.Text = "课程号";
            this.label2.Text = "学生号";
            this.label3.Text = "考试时间";
            this.label4.Text = "考试成绩";
        }

        private void save_bt_Click(object sender, EventArgs e)
        {
            this.connection.Open();
            try
            {
                this.adapter.Update(this.dataSet1);
                this.dataSet1.Clear();
                this.adapter.Fill(this.dataSet1);
            }
            catch
            {
                MessageBox.Show("修改不当");
            }
            finally
            {
                this.connection.Close();
            }
        }

        private void delete_bt_Click(object sender, EventArgs e)
        {
            // 从显示表格中获取员工编号 
            int nCustomerID
                = Int32.Parse(this.dataGrid1[this.dataGrid1.CurrentRowIndex, 0].ToString());
            //String a = this.dataGrid2[this.dataGrid2.CurrentRowIndex, 1].ToString();
            // 构造Customer表的删除命令 
            String strCustomerDelete = "DELETE Course WHERE Course_Id ='" + nCustomerID.ToString() + "'";
            OleDbCommand cmdCustomerDelete
               = new OleDbCommand(strCustomerDelete, this.connection);

            this.connection.Open();

            try
            {
                cmdCustomerDelete.ExecuteNonQuery();

                // 刷新显示内容 
                this.dataSet1.Clear();
                this.adapter.Fill(this.dataSet1);
            }
            catch
            {
                MessageBox.Show("该考试无法删除");
            }
            finally
            {
                this.connection.Close();
            }
        }

        private void insert_bt_Click(object sender, EventArgs e)
        {
            String cmdInsert = "insert into Examination values (?,?,?,?)";
            OleDbCommand cmd = new OleDbCommand(cmdInsert, connection);

            cmd.Parameters.Add("@p1", OleDbType.VarChar, 20).Value
                = this.textBox1.Text;
            cmd.Parameters.Add("@p2", OleDbType.VarChar, 20).Value
                = this.textBox2.Text;
            cmd.Parameters.Add("@p3", OleDbType.VarChar, 20).Value
                = this.textBox3.Text;
            cmd.Parameters.Add("@p4", OleDbType.VarChar, 20).Value
                = this.textBox4.Text;

            this.connection.Open();

            try
            {
                cmd.ExecuteNonQuery();
                this.dataSet1.Clear();
                this.adapter.Fill(this.dataSet1);
            }
            catch
            {
                MessageBox.Show("信息填写错误，请检查");
            }
            finally
            {
                this.connection.Close();
            }
        }
    }
}
