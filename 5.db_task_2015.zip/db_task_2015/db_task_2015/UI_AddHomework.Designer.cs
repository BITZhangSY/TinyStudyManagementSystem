﻿namespace db_task_2015
{
    partial class UI_AddHomework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CommitDate_textBox = new System.Windows.Forms.TextBox();
            this.StudentId_label = new System.Windows.Forms.Label();
            this.课程管理 = new System.Windows.Forms.Label();
            this.content_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AddHowork_bt = new System.Windows.Forms.Button();
            this.HomeworkNum_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CommitDate_textBox
            // 
            this.CommitDate_textBox.Location = new System.Drawing.Point(143, 50);
            this.CommitDate_textBox.Name = "CommitDate_textBox";
            this.CommitDate_textBox.Size = new System.Drawing.Size(123, 21);
            this.CommitDate_textBox.TabIndex = 17;
            // 
            // StudentId_label
            // 
            this.StudentId_label.AutoSize = true;
            this.StudentId_label.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.StudentId_label.Location = new System.Drawing.Point(33, 50);
            this.StudentId_label.Name = "StudentId_label";
            this.StudentId_label.Size = new System.Drawing.Size(74, 21);
            this.StudentId_label.TabIndex = 16;
            this.StudentId_label.Text = "提交日期";
            // 
            // 课程管理
            // 
            this.课程管理.AutoSize = true;
            this.课程管理.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.课程管理.Location = new System.Drawing.Point(12, 9);
            this.课程管理.Name = "课程管理";
            this.课程管理.Size = new System.Drawing.Size(88, 26);
            this.课程管理.TabIndex = 18;
            this.课程管理.Text = "布置作业";
            // 
            // content_textBox
            // 
            this.content_textBox.Location = new System.Drawing.Point(117, 138);
            this.content_textBox.Multiline = true;
            this.content_textBox.Name = "content_textBox";
            this.content_textBox.Size = new System.Drawing.Size(226, 80);
            this.content_textBox.TabIndex = 44;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(44, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 21);
            this.label3.TabIndex = 43;
            this.label3.Text = "内容";
            // 
            // AddHowork_bt
            // 
            this.AddHowork_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.AddHowork_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddHowork_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AddHowork_bt.ForeColor = System.Drawing.Color.White;
            this.AddHowork_bt.Location = new System.Drawing.Point(253, 238);
            this.AddHowork_bt.Name = "AddHowork_bt";
            this.AddHowork_bt.Size = new System.Drawing.Size(59, 25);
            this.AddHowork_bt.TabIndex = 45;
            this.AddHowork_bt.Text = "添加";
            this.AddHowork_bt.UseVisualStyleBackColor = false;
            this.AddHowork_bt.Click += new System.EventHandler(this.AddHowork_bt_Click);
            // 
            // HomeworkNum_textBox
            // 
            this.HomeworkNum_textBox.Location = new System.Drawing.Point(143, 94);
            this.HomeworkNum_textBox.Name = "HomeworkNum_textBox";
            this.HomeworkNum_textBox.Size = new System.Drawing.Size(123, 21);
            this.HomeworkNum_textBox.TabIndex = 46;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(38, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 21);
            this.label1.TabIndex = 47;
            this.label1.Text = "作业号";
            // 
            // UI_AddHomework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(432, 288);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.HomeworkNum_textBox);
            this.Controls.Add(this.AddHowork_bt);
            this.Controls.Add(this.content_textBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.课程管理);
            this.Controls.Add(this.CommitDate_textBox);
            this.Controls.Add(this.StudentId_label);
            this.Name = "UI_AddHomework";
            this.Text = "UI_AddHomework";
            this.Load += new System.EventHandler(this.UI_AddHomework_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox CommitDate_textBox;
        private System.Windows.Forms.Label StudentId_label;
        private System.Windows.Forms.Label 课程管理;
        private System.Windows.Forms.TextBox content_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button AddHowork_bt;
        private System.Windows.Forms.TextBox HomeworkNum_textBox;
        private System.Windows.Forms.Label label1;
    }
}