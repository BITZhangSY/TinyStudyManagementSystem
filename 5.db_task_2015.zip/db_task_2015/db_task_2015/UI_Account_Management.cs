﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
using Entity;
using Bll;

namespace db_task_2015
{
    public partial class UI_Account_Management : Form
    {
        
        public UI_Account_Management()
        {
            InitializeComponent();
        
        }

        private void dataGrid1_Navigate(object sender, NavigateEventArgs ne)
        {
        }

        private void UI_Account_Management_Load(object sender, EventArgs e)
        {
            this.adapter.Fill(this.dataSet1);
        }

        private void save_bt_Click(object sender, EventArgs e)
        {
            this.connection.Open();
            try
            {
                this.adapter.Update(this.dataSet1);
                this.dataSet1.Clear();
                this.adapter.Fill(this.dataSet1);
            }
            catch
            {
                MessageBox.Show("修改不当");
            }
            finally
            {
                this.connection.Close();
            }
        }

        private void delete_bt_Click(object sender, EventArgs e)
        {
            int nCustomerID
                = Int32.Parse(this.dataGrid1[this.dataGrid1.CurrentRowIndex, 0].ToString());
           
            String strCustomerDelete = "DELETE Stuff WHERE Stuff_Id ='" + nCustomerID.ToString() + "'";
            OleDbCommand cmdCustomerDelete
               = new OleDbCommand(strCustomerDelete, this.connection);

            String type = this.dataGrid1[this.dataGrid1.CurrentRowIndex, 3].ToString();

            String cmdDeleteCascade = "";
            if (type.Equals("管理员"))
            {
                cmdDeleteCascade = "delete from Administrator where Stuff_Id='" + nCustomerID.ToString() + "'";
            }
            else if (type.Equals("老师"))
            {
                cmdDeleteCascade = "delete from Teacher where Stuff_Id='" + nCustomerID.ToString() + "'";

            }
            else if (type.Equals("学生"))
            {
                cmdDeleteCascade = "delete from Student where Stuff_Id='" + nCustomerID.ToString() + "'";
            }

            OleDbCommand cmd_cascade = new OleDbCommand(cmdDeleteCascade, connection);

            this.connection.Open();

            try
            {
                cmdCustomerDelete.ExecuteNonQuery();
                cmd_cascade.ExecuteNonQuery();
                // 刷新显示内容 
                this.dataSet1.Clear();
                this.adapter.Fill(this.dataSet1);
            }
            catch
            {
                MessageBox.Show("操作失败，请检查操作是否正确");
            }
            finally
            {
                this.connection.Close();
            }
        }

        private void insert_AccountInfo_bt_Click(object sender, EventArgs e)
        {
            String cmdInsert = "insert into Stuff values (?,?,?,?,?)";
            OleDbCommand cmd = new OleDbCommand(cmdInsert, connection);

            String type = "";
            String cmdInsertCascade = "";
            bool is_parameter_correct = true;

            if (this.type_textBox.Text.Equals("管理员"))
            {
                type = "Administrator";
                cmdInsertCascade = "insert into " + type + " values('" + this.id_textBox.Text
                                    + "')";                                      
            }else if (this.type_textBox.Text.Equals("老师"))
            {
                type = "Teacher";
                cmdInsertCascade = "insert into " + type + " values('" + this.id_textBox.Text
                                    + "','未知')";
            }
            else if (this.type_textBox.Text.Equals("学生"))
            {
                type = "Student";
                cmdInsertCascade = "insert into " + type + " values('" + this.id_textBox.Text
                                    + "','未知')";
            }
            else
            {
                MessageBox.Show("类型填写错误");
                is_parameter_correct = false;
            }
            if (is_parameter_correct)
            {
                OleDbCommand cmd_cascade = new OleDbCommand(cmdInsertCascade, connection);

                cmd.Parameters.Add("@p1", OleDbType.VarChar, 20).Value
                = this.id_textBox.Text;
                cmd.Parameters.Add("@p2", OleDbType.VarChar, 20).Value
                    = this.account_textBox.Text;
                cmd.Parameters.Add("@p3", OleDbType.VarChar, 20).Value
                    = this.pass_textBox.Text;
                cmd.Parameters.Add("@p4", OleDbType.VarChar, 20).Value
                    = this.type_textBox.Text;
                cmd.Parameters.Add("@p5", OleDbType.VarChar, 20).Value
                    = this.name_textBox.Text;

                this.connection.Open();

                try
                {
                    cmd.ExecuteNonQuery();

                    cmd_cascade.ExecuteNonQuery();


                    this.dataSet1.Clear();
                    this.adapter.Fill(this.dataSet1);
                }
                catch
                {
                    MessageBox.Show("操作失败，请检查类型是否匹配");
                }
                finally
                {
                    this.connection.Close();
                }               
            }            
        }

        private void connection_InfoMessage(object sender, OleDbInfoMessageEventArgs e)
        {

        }
    }
}
