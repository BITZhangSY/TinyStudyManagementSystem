﻿namespace db_task_2015
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.cancel = new System.Windows.Forms.Button();
            this.login = new System.Windows.Forms.Button();
            this.userChoose_groupBox = new System.Windows.Forms.GroupBox();
            this.admin_radioButton = new System.Windows.Forms.RadioButton();
            this.teacher_radioButton = new System.Windows.Forms.RadioButton();
            this.student_radioButton = new System.Windows.Forms.RadioButton();
            this.password_textBox = new System.Windows.Forms.TextBox();
            this.account_textbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.userChoose_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.Color.Chocolate;
            this.label3.Location = new System.Drawing.Point(40, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(254, 31);
            this.label3.TabIndex = 16;
            this.label3.Text = "教学管理平台认证登录";
            // 
            // cancel
            // 
            this.cancel.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.cancel.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cancel.ForeColor = System.Drawing.Color.White;
            this.cancel.Location = new System.Drawing.Point(174, 223);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(97, 35);
            this.cancel.TabIndex = 23;
            this.cancel.Text = "取消";
            this.cancel.UseVisualStyleBackColor = false;
            // 
            // login
            // 
            this.login.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.login.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.login.ForeColor = System.Drawing.Color.White;
            this.login.Location = new System.Drawing.Point(30, 223);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(97, 35);
            this.login.TabIndex = 22;
            this.login.Text = "登录";
            this.login.UseVisualStyleBackColor = false;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // userChoose_groupBox
            // 
            this.userChoose_groupBox.AutoSize = true;
            this.userChoose_groupBox.Controls.Add(this.admin_radioButton);
            this.userChoose_groupBox.Controls.Add(this.teacher_radioButton);
            this.userChoose_groupBox.Controls.Add(this.student_radioButton);
            this.userChoose_groupBox.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userChoose_groupBox.Location = new System.Drawing.Point(329, 100);
            this.userChoose_groupBox.Name = "userChoose_groupBox";
            this.userChoose_groupBox.Size = new System.Drawing.Size(160, 142);
            this.userChoose_groupBox.TabIndex = 21;
            this.userChoose_groupBox.TabStop = false;
            this.userChoose_groupBox.Text = "您的身份是";
            // 
            // admin_radioButton
            // 
            this.admin_radioButton.AutoSize = true;
            this.admin_radioButton.ForeColor = System.Drawing.Color.Black;
            this.admin_radioButton.Location = new System.Drawing.Point(17, 93);
            this.admin_radioButton.Name = "admin_radioButton";
            this.admin_radioButton.Size = new System.Drawing.Size(69, 24);
            this.admin_radioButton.TabIndex = 2;
            this.admin_radioButton.TabStop = true;
            this.admin_radioButton.Text = "管理员";
            this.admin_radioButton.UseVisualStyleBackColor = true;
            // 
            // teacher_radioButton
            // 
            this.teacher_radioButton.AutoSize = true;
            this.teacher_radioButton.ForeColor = System.Drawing.Color.Black;
            this.teacher_radioButton.Location = new System.Drawing.Point(17, 63);
            this.teacher_radioButton.Name = "teacher_radioButton";
            this.teacher_radioButton.Size = new System.Drawing.Size(55, 24);
            this.teacher_radioButton.TabIndex = 1;
            this.teacher_radioButton.TabStop = true;
            this.teacher_radioButton.Text = "老师";
            this.teacher_radioButton.UseVisualStyleBackColor = true;
            // 
            // student_radioButton
            // 
            this.student_radioButton.AutoSize = true;
            this.student_radioButton.ForeColor = System.Drawing.Color.Black;
            this.student_radioButton.Location = new System.Drawing.Point(17, 33);
            this.student_radioButton.Name = "student_radioButton";
            this.student_radioButton.Size = new System.Drawing.Size(55, 24);
            this.student_radioButton.TabIndex = 0;
            this.student_radioButton.TabStop = true;
            this.student_radioButton.Text = "学生";
            this.student_radioButton.UseVisualStyleBackColor = true;
            // 
            // password_textBox
            // 
            this.password_textBox.Location = new System.Drawing.Point(123, 168);
            this.password_textBox.Name = "password_textBox";
            this.password_textBox.Size = new System.Drawing.Size(100, 21);
            this.password_textBox.TabIndex = 20;
            // 
            // account_textbox
            // 
            this.account_textbox.Location = new System.Drawing.Point(123, 114);
            this.account_textbox.Name = "account_textbox";
            this.account_textbox.Size = new System.Drawing.Size(100, 21);
            this.account_textbox.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.ForestGreen;
            this.label2.Location = new System.Drawing.Point(61, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 21);
            this.label2.TabIndex = 18;
            this.label2.Text = "密码";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.ForestGreen;
            this.label1.Location = new System.Drawing.Point(54, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 21);
            this.label1.TabIndex = 17;
            this.label1.Text = "用户名";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(578, 335);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.login);
            this.Controls.Add(this.userChoose_groupBox);
            this.Controls.Add(this.password_textBox);
            this.Controls.Add(this.account_textbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Name = "Form1";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.userChoose_groupBox.ResumeLayout(false);
            this.userChoose_groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.GroupBox userChoose_groupBox;
        private System.Windows.Forms.RadioButton admin_radioButton;
        private System.Windows.Forms.RadioButton teacher_radioButton;
        private System.Windows.Forms.RadioButton student_radioButton;
        private System.Windows.Forms.TextBox password_textBox;
        private System.Windows.Forms.TextBox account_textbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

