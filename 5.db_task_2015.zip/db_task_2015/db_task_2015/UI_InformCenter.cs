﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Entity;
using Bll;
namespace db_task_2015
{
    public partial class UI_InformCenter : Form
    {
        String stuff_id;
        public UI_InformCenter(String stuff_id)
        {
            InitializeComponent();
            this.stuff_id = stuff_id;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void send_inform_bt_Click(object sender, EventArgs e)
        {
            String info_id = this.infoId_textBox.Text;
            String title = this.title_textBox.Text;
            String content = this.content_textBox.Text;
            String type = this.type_textBox.Text;
            

            bll a = new bll();

            if(a.insert_Inform(info_id, type, content, title, stuff_id))
            {
                MessageBox.Show("发布消息成功");
            }
            else
            {
                MessageBox.Show("发布消息失败");
            }
        }

        private void UI_InformCenter_Load(object sender, EventArgs e)
        {
            bll a = new bll();

            List<Inform> list = a.get_Inform();
            
            if(null == list)
            {
                MessageBox.Show("当前无任何通知");
            }
            else
            {
                // Set the view to show details.
                this.inform_content_lv.View = View.Details;
                // Allow the user to edit item text.
                this.inform_content_lv.LabelEdit = true;
                // Allow the user to rearrange columns.
                this.inform_content_lv.AllowColumnReorder = true;
                // Display check boxes.
                this.inform_content_lv.CheckBoxes = false;
                // Select the item and subitems when selection is made.
                this.inform_content_lv.FullRowSelect = true;
                // Display grid lines.
                this.inform_content_lv.GridLines = true;
                // Sort the items in the list in ascending order.
                this.inform_content_lv.Sorting = SortOrder.Ascending;
                
                this.inform_content_lv.Columns.Add("通知编号", 100, HorizontalAlignment.Left);
                this.inform_content_lv.Columns.Add("类型", 100, HorizontalAlignment.Left);
                this.inform_content_lv.Columns.Add("名称", 100, HorizontalAlignment.Left);
                this.inform_content_lv.Columns.Add("具体内容", 200, HorizontalAlignment.Left);

                for(int i=0; i<list.Count; i++)
                {
                    Inform inform = list[i];

                    ListViewItem item = new ListViewItem(inform.info_id);
                    item.SubItems.Add(inform.type);
                    item.SubItems.Add(inform.title);
                    item.SubItems.Add(inform.content);

                    this.inform_content_lv.Items.Add(item);
                }
            }
        }
    }
}
