﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Bll;
using Entity;

namespace db_task_2015
{
    public partial class UI_CommonWindow_ForStudent : Form
    {
        bll a = new bll();

        int flag;
        String student_id;
        public UI_CommonWindow_ForStudent(int flag, String student_id)
        {
            InitializeComponent();
            this.flag = flag;
            this.student_id = student_id;
        }

        private void UI_CommonWindow_ForStudent_Load(object sender, EventArgs e)
        {

            setLv_configuration();

            if (2 == flag)
            {
                this.common_label.Text = "课表";
                setLv_schedule();
            }
            else if(3 == flag)
            {
                this.common_label.Text = "考试";
                setLv_test();
            }
            else if (4 == flag)
            {
                this.common_label.Text = "成绩";
                setLv_score();
            }
            else if(5 == flag)
            {
                this.common_label.Text = "作业";
                setLv_Homework();
            }
        }

        private void setLv_schedule()
        {
            List<Course> list = a.get_Course(student_id);

            this.content_lv.Columns.Add("课程号", 100, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("课程名", 100, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("上课时间", 100, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("上课地点", 100, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("课任老师", 100, HorizontalAlignment.Left);


            for (int i=0; i<list.Count; i++)
            {
                Course course = list[i];

                ListViewItem item = new ListViewItem(course.Course_Id);
                item.SubItems.Add(course.Name);
                item.SubItems.Add(course.Schedule);
                item.SubItems.Add(course.Classroom);
                item.SubItems.Add(course.Teacher_Name);

                this.content_lv.Items.Add(item);
            }
        }

        private void setLv_test()
        {
            List<Examination> list = a.get_Exam(student_id);

            this.content_lv.Columns.Add("课程名", 150, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("考试时间", 300, HorizontalAlignment.Left);

            for(int i=0; i<list.Count; i++)
            {
                Examination exam = list[i];

                ListViewItem item = new ListViewItem(exam.Course_Name);
                item.SubItems.Add(exam.Date);

                this.content_lv.Items.Add(item);
            }
        }

        private void setLv_score()
        {
            List<Examination> list = a.get_Exam(student_id);

            this.content_lv.Columns.Add("课程名", 150, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("考试成绩", 300, HorizontalAlignment.Left);

            for (int i = 0; i < list.Count; i++)
            {
                Examination exam = list[i];

                ListViewItem item = new ListViewItem(exam.Course_Name);
                item.SubItems.Add(exam.Score);

                this.content_lv.Items.Add(item);
            }
        }

        private void setLv_Homework()
        {
            List<Homework> list = a.get_Homework(student_id);

            this.content_lv.Columns.Add("作业号", 50, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("作业内容", 200, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("提交时间", 100, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("课程名称", 100, HorizontalAlignment.Left);
            this.content_lv.Columns.Add("任课老师", 50, HorizontalAlignment.Left);


            for (int i = 0; i < list.Count; i++)
            {
                Homework homework = list[i];

                ListViewItem item = new ListViewItem(homework.homework_id);
                item.SubItems.Add(homework.content);
                item.SubItems.Add(homework.date);
                item.SubItems.Add(homework.course_name);
                item.SubItems.Add(homework.teacher_name);

                this.content_lv.Items.Add(item);
            }
        }

        private void setLv_configuration()
        {
            // Set the view to show details.
            this.content_lv.View = View.Details;
            // Allow the user to edit item text.
            this.content_lv.LabelEdit = true;
            // Allow the user to rearrange columns.
            this.content_lv.AllowColumnReorder = true;
            // Display check boxes.
            this.content_lv.CheckBoxes = false;
            // Select the item and subitems when selection is made.
            this.content_lv.FullRowSelect = true;
            // Display grid lines.
            this.content_lv.GridLines = true;
            // Sort the items in the list in ascending order.
            this.content_lv.Sorting = SortOrder.Ascending;
        }
    }
}
