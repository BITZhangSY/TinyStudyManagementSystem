﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Bll;

namespace db_task_2015
{
    public partial class UI_AddHomework : Form
    {
        String teacher_id;
        String course_id;
        bll a = new bll();

        public UI_AddHomework(String teacher_id, String course_id)
        {
            InitializeComponent();
            this.teacher_id = teacher_id;
            this.course_id = course_id;
        }

        private void UI_AddHomework_Load(object sender, EventArgs e)
        {

        }

        private void AddHowork_bt_Click(object sender, EventArgs e)
        {

            String date = DateTime.Parse(this.CommitDate_textBox.Text).ToString();
            String content = this.content_textBox.Text;
            String num = this.HomeworkNum_textBox.Text;

            if(!num.Equals(null) && !date.Equals(null) && !content.Equals(null))
            {
                bool if_success = a.add_homework(num, content, date, course_id, teacher_id);
                if (if_success)
                    MessageBox.Show("布置成功!");
                else
                    MessageBox.Show("布置失败!");
            }
            else
            {
                MessageBox.Show("请填写完整信息");
            }
        }
    }
}
