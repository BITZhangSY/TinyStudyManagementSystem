﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Bll;

namespace db_task_2015
{
    public partial class UI_AddStudent : Form
    {
        String course_id;
        bll a = new bll();
        public UI_AddStudent(String course_id)
        {
            InitializeComponent();
            this.course_id = course_id;
        }

        private void AddStu_bt_Click(object sender, EventArgs e)
        {
            String student_id = this.StudentId_textBox.Text;
            if (!student_id.Equals(null))
            {
                bool if_success = a.add_student(student_id, course_id);
                if (if_success)
                    MessageBox.Show("添加成功!");
                else
                    MessageBox.Show("添加失败!");
            }
            else
            {
                MessageBox.Show("请填写完整信息！");
            }
            
        }
    }
}
