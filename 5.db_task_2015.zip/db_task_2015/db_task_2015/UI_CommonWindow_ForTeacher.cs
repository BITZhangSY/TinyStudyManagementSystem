﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace db_task_2015
{
    public partial class UI_CommonWindow_ForTeacher : Form
    {
        String stuff_id;
        public UI_CommonWindow_ForTeacher(String stuff_id)
        {
            InitializeComponent();
            this.stuff_id = stuff_id;
        }

        private void save_bt_Click(object sender, EventArgs e)
        {
            this.connection.Open();
            this.adapter.Update(this.dataSet1);
            this.dataSet1.Clear();
            this.adapter.Fill(this.dataSet1);
            this.connection.Close();
        }

        private void UI_CommonWindow_ForTeacher_Load(object sender, EventArgs e)
        {
            this.adapter.Fill(this.dataSet1);

            this.label1.Text = "课程号";
            this.label2.Text = "课程名";
            this.label3.Text = "上课时间";
            this.label4.Text = "上课地点";
            

        }

        private void delete_bt_Click(object sender, EventArgs e)
        {
            // 从显示表格中获取员工编号 
            int nCustomerID
                = Int32.Parse(this.dataGrid1[this.dataGrid1.CurrentRowIndex, 0].ToString());
            //String a = this.dataGrid2[this.dataGrid2.CurrentRowIndex, 1].ToString();
            // 构造Customer表的删除命令 
            String strCustomerDelete = "DELETE Course WHERE Course_Id ='" + nCustomerID.ToString() + "'";
            OleDbCommand cmdCustomerDelete
               = new OleDbCommand(strCustomerDelete, this.connection);

            this.connection.Open();

            try
            {
                cmdCustomerDelete.ExecuteNonQuery();
                // 刷新显示内容 
                this.dataSet1.Clear();
                this.adapter.Fill(this.dataSet1);
            }
            catch
            {
                MessageBox.Show("操作不当，无法删除");
            }
            finally
            {
                this.connection.Close();
            }
        }

        private void insert_bt_Click(object sender, EventArgs e)
        {
            String cmdInsert = "insert into Course values (?,?,?,?,?)";
            OleDbCommand cmd = new OleDbCommand(cmdInsert, connection);

            cmd.Parameters.Add("@p1", OleDbType.VarChar, 20).Value
                = this.textBox1.Text;
            cmd.Parameters.Add("@p2", OleDbType.VarChar, 20).Value
                = this.textBox2.Text;
            cmd.Parameters.Add("@p3", OleDbType.VarChar, 20).Value
                = this.textBox3.Text;
            cmd.Parameters.Add("@p4", OleDbType.VarChar, 20).Value
                = this.textBox4.Text;
            cmd.Parameters.Add("@p5", OleDbType.VarChar, 20).Value
                = stuff_id;

            this.connection.Open();

            cmd.ExecuteNonQuery();

            this.connection.Close();
            this.dataSet1.Clear();
            this.adapter.Fill(this.dataSet1);
        }

        private void connection_InfoMessage(object sender, OleDbInfoMessageEventArgs e)
        {

        }

        private void AddStu_bt_Click(object sender, EventArgs e)
        {
            String course_id = this.dataGrid1[this.dataGrid1.CurrentRowIndex, 0].ToString();
            if (course_id.Equals(null))
            {
                MessageBox.Show("请选择一项课程!");
            }
            else
            {
                UI_AddStudent add_student = new UI_AddStudent(course_id);
                add_student.Show();
            }
            
        }

        private void AddHowork_bt_Click(object sender, EventArgs e)
        {
            String course_id = this.dataGrid1[this.dataGrid1.CurrentRowIndex, 0].ToString();
            if (course_id.Equals(null))
            {
                MessageBox.Show("请选择一项课程!");
            }
            else
            {
                UI_AddHomework add_homework = new UI_AddHomework(stuff_id,course_id);
                add_homework.Show();
            }
        }
    }
}
