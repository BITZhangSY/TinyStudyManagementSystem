﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Bll;
using Entity;

namespace db_task_2015
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {
            String account = this.account_textbox.Text;
            String password = this.password_textBox.Text;

            if (account == "" || password == "")
            {
                MessageBox.Show("请填写完整的账户信息");
            }
            else
            {
                int flag = -1;
                if (this.student_radioButton.Checked)
                {
                    flag = 0;
                }
                else if (this.teacher_radioButton.Checked)
                {
                    flag = 1;
                }
                else if (this.admin_radioButton.Checked)
                {
                    flag = 2;
                }

                if (-1 == flag)
                {
                    MessageBox.Show("请选择您的登录类型");
                }
                else
                {
                    bll a = new bll();                                                           
                    Account info_account = a.check_login_info(account, password, flag);

                    if(null == info_account)
                    {
                        MessageBox.Show("您填写的信息有误，请重新登录！");
                    }
                    else
                    {
                        UI_Main_interface main_interface = new UI_Main_interface(info_account.stuff_id,
                            info_account.account, info_account.password, 
                            info_account.name, info_account.type, flag);
                        //this.IsMdiContainer = true;
                        // main_interface.MdiParent = this;
                        //this.Hide();
                        main_interface.Show();
                        //this.Close();
                        
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.password_textBox.PasswordChar = '*';
        }
    }
}
