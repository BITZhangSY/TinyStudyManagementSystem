﻿namespace db_task_2015
{
    partial class UI_CommonWindow_ForStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.common_label = new System.Windows.Forms.Label();
            this.content_lv = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // common_label
            // 
            this.common_label.AutoSize = true;
            this.common_label.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.common_label.Location = new System.Drawing.Point(12, 9);
            this.common_label.Name = "common_label";
            this.common_label.Size = new System.Drawing.Size(88, 26);
            this.common_label.TabIndex = 12;
            this.common_label.Text = "通知中心";
            // 
            // content_lv
            // 
            this.content_lv.BackColor = System.Drawing.Color.OldLace;
            this.content_lv.Location = new System.Drawing.Point(27, 53);
            this.content_lv.Name = "content_lv";
            this.content_lv.Size = new System.Drawing.Size(522, 240);
            this.content_lv.TabIndex = 13;
            this.content_lv.UseCompatibleStateImageBehavior = false;
            // 
            // UI_CommonWindow_ForStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(579, 342);
            this.Controls.Add(this.content_lv);
            this.Controls.Add(this.common_label);
            this.Name = "UI_CommonWindow_ForStudent";
            this.Text = "UI_CommonWindow_ForStudent";
            this.Load += new System.EventHandler(this.UI_CommonWindow_ForStudent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label common_label;
        private System.Windows.Forms.ListView content_lv;
    }
}