﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Bll;

namespace db_task_2015
{
    public partial class UI_PersonalCenter : Form
    {
        String stuff_id;
        String account;
        String password;
        String name;
        String type;
        public UI_PersonalCenter(String stuff_id, String account, String password,
                                 String name, String type)
        {
            InitializeComponent();
            this.stuff_id = stuff_id;
            this.account = account;
            this.password = password;
            this.name = name;
            this.type = type;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.formor_pass_textBox.Clear();
            this.new_pass_textBox.Clear();
            this.confirm_pass_textBox.Clear();
        }

        private void UI_PersonalCenter_Load(object sender, EventArgs e)
        {
            this.account_label.Text = account;
            this.name_label.Text = name;
            this.type_label.Text = type;

            this.formor_pass_textBox.PasswordChar = '*';
            this.new_pass_textBox.PasswordChar = '*';
            this.confirm_pass_textBox.PasswordChar = '*';
        }

        private void submit_pass_change_Click(object sender, EventArgs e)
        {
            String formor_pass = formor_pass_textBox.Text;
            String new_pass = new_pass_textBox.Text;
            String confirm_new_pass = confirm_pass_textBox.Text;
            if(formor_pass == "" || new_pass == "" || confirm_new_pass == "")
            {
                MessageBox.Show("请填写完整信息!");
            }
            else if (String.Equals(password, formor_pass))
            {
                MessageBox.Show("输入原有密码有误，请重新输入");
            }else if (!String.Equals(new_pass, confirm_new_pass))
            {
                MessageBox.Show("新密码输入不一致，请重新输入");
            }
            else
            {
                bll a = new bll();
                if(a.change_password(stuff_id, new_pass)){
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    MessageBox.Show("修改失败...");
                }
            }
        }
    }
}
