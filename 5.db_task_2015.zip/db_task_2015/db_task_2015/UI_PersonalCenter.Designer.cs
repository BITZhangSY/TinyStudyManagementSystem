﻿namespace db_task_2015
{
    partial class UI_PersonalCenter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.type_label = new System.Windows.Forms.Label();
            this.name_label = new System.Windows.Forms.Label();
            this.account_label = new System.Windows.Forms.Label();
            this.formal_pass_label = new System.Windows.Forms.Label();
            this.formor_pass_textBox = new System.Windows.Forms.TextBox();
            this.new_pass_textBox = new System.Windows.Forms.TextBox();
            this.new_pass_label = new System.Windows.Forms.Label();
            this.confirm_pass_textBox = new System.Windows.Forms.TextBox();
            this.confirm_label = new System.Windows.Forms.Label();
            this.submit_pass_change = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "个人中心";
            // 
            // type_label
            // 
            this.type_label.AutoSize = true;
            this.type_label.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.type_label.ForeColor = System.Drawing.SystemColors.InfoText;
            this.type_label.Location = new System.Drawing.Point(28, 193);
            this.type_label.Name = "type_label";
            this.type_label.Size = new System.Drawing.Size(74, 21);
            this.type_label.TabIndex = 30;
            this.type_label.Text = "用户类型";
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.name_label.ForeColor = System.Drawing.SystemColors.InfoText;
            this.name_label.Location = new System.Drawing.Point(28, 134);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(42, 21);
            this.name_label.TabIndex = 29;
            this.name_label.Text = "名称";
            // 
            // account_label
            // 
            this.account_label.AutoSize = true;
            this.account_label.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.account_label.ForeColor = System.Drawing.SystemColors.InfoText;
            this.account_label.Location = new System.Drawing.Point(28, 75);
            this.account_label.Name = "account_label";
            this.account_label.Size = new System.Drawing.Size(42, 21);
            this.account_label.TabIndex = 28;
            this.account_label.Text = "账号";
            // 
            // formal_pass_label
            // 
            this.formal_pass_label.AutoSize = true;
            this.formal_pass_label.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.formal_pass_label.Location = new System.Drawing.Point(196, 55);
            this.formal_pass_label.Name = "formal_pass_label";
            this.formal_pass_label.Size = new System.Drawing.Size(51, 20);
            this.formal_pass_label.TabIndex = 31;
            this.formal_pass_label.Text = "原密码";
            // 
            // formor_pass_textBox
            // 
            this.formor_pass_textBox.Location = new System.Drawing.Point(284, 56);
            this.formor_pass_textBox.Name = "formor_pass_textBox";
            this.formor_pass_textBox.Size = new System.Drawing.Size(138, 21);
            this.formor_pass_textBox.TabIndex = 32;
            // 
            // new_pass_textBox
            // 
            this.new_pass_textBox.Location = new System.Drawing.Point(284, 116);
            this.new_pass_textBox.Name = "new_pass_textBox";
            this.new_pass_textBox.Size = new System.Drawing.Size(138, 21);
            this.new_pass_textBox.TabIndex = 34;
            // 
            // new_pass_label
            // 
            this.new_pass_label.AutoSize = true;
            this.new_pass_label.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.new_pass_label.Location = new System.Drawing.Point(196, 115);
            this.new_pass_label.Name = "new_pass_label";
            this.new_pass_label.Size = new System.Drawing.Size(51, 20);
            this.new_pass_label.TabIndex = 33;
            this.new_pass_label.Text = "新密码";
            // 
            // confirm_pass_textBox
            // 
            this.confirm_pass_textBox.Location = new System.Drawing.Point(284, 177);
            this.confirm_pass_textBox.Name = "confirm_pass_textBox";
            this.confirm_pass_textBox.Size = new System.Drawing.Size(138, 21);
            this.confirm_pass_textBox.TabIndex = 36;
            // 
            // confirm_label
            // 
            this.confirm_label.AutoSize = true;
            this.confirm_label.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.confirm_label.Location = new System.Drawing.Point(185, 176);
            this.confirm_label.Name = "confirm_label";
            this.confirm_label.Size = new System.Drawing.Size(79, 20);
            this.confirm_label.TabIndex = 35;
            this.confirm_label.Text = "再输入一次";
            // 
            // submit_pass_change
            // 
            this.submit_pass_change.BackColor = System.Drawing.Color.LightSeaGreen;
            this.submit_pass_change.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.submit_pass_change.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.submit_pass_change.ForeColor = System.Drawing.Color.White;
            this.submit_pass_change.Location = new System.Drawing.Point(229, 245);
            this.submit_pass_change.Name = "submit_pass_change";
            this.submit_pass_change.Size = new System.Drawing.Size(56, 25);
            this.submit_pass_change.TabIndex = 37;
            this.submit_pass_change.Text = "提交";
            this.submit_pass_change.UseVisualStyleBackColor = false;
            this.submit_pass_change.Click += new System.EventHandler(this.submit_pass_change_Click);
            // 
            // cancel
            // 
            this.cancel.BackColor = System.Drawing.Color.LightSeaGreen;
            this.cancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancel.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cancel.ForeColor = System.Drawing.Color.White;
            this.cancel.Location = new System.Drawing.Point(366, 245);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(56, 25);
            this.cancel.TabIndex = 38;
            this.cancel.Text = "取消";
            this.cancel.UseVisualStyleBackColor = false;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // UI_PersonalCenter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(551, 341);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.submit_pass_change);
            this.Controls.Add(this.confirm_pass_textBox);
            this.Controls.Add(this.confirm_label);
            this.Controls.Add(this.new_pass_textBox);
            this.Controls.Add(this.new_pass_label);
            this.Controls.Add(this.formor_pass_textBox);
            this.Controls.Add(this.formal_pass_label);
            this.Controls.Add(this.type_label);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.account_label);
            this.Controls.Add(this.label1);
            this.Name = "UI_PersonalCenter";
            this.Text = "UI_PersonalCenter";
            this.Load += new System.EventHandler(this.UI_PersonalCenter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label type_label;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label account_label;
        private System.Windows.Forms.Label formal_pass_label;
        private System.Windows.Forms.TextBox formor_pass_textBox;
        private System.Windows.Forms.TextBox new_pass_textBox;
        private System.Windows.Forms.Label new_pass_label;
        private System.Windows.Forms.TextBox confirm_pass_textBox;
        private System.Windows.Forms.Label confirm_label;
        private System.Windows.Forms.Button submit_pass_change;
        private System.Windows.Forms.Button cancel;
    }
}