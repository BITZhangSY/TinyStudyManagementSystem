﻿namespace db_task_2015
{
    partial class UI_CommonWindow_ForTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UI_CommonWindow_ForTeacher));
            this.课程管理 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.insert_bt = new System.Windows.Forms.Button();
            this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
            this.connection = new System.Data.OleDb.OleDbConnection();
            this.oleDbInsertCommand1 = new System.Data.OleDb.OleDbCommand();
            this.oleDbUpdateCommand1 = new System.Data.OleDb.OleDbCommand();
            this.oleDbDeleteCommand1 = new System.Data.OleDb.OleDbCommand();
            this.adapter = new System.Data.OleDb.OleDbDataAdapter();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.dataSet1 = new db_task_2015.dataSet();
            this.delete_bt = new System.Windows.Forms.Button();
            this.save_bt = new System.Windows.Forms.Button();
            this.AddStu_bt = new System.Windows.Forms.Button();
            this.AddHowork_bt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // 课程管理
            // 
            this.课程管理.AutoSize = true;
            this.课程管理.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.课程管理.Location = new System.Drawing.Point(12, 9);
            this.课程管理.Name = "课程管理";
            this.课程管理.Size = new System.Drawing.Size(88, 26);
            this.课程管理.TabIndex = 11;
            this.课程管理.Text = "课程管理";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(107, 50);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(34, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 21);
            this.label1.TabIndex = 12;
            this.label1.Text = "编号";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(325, 53);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(252, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 21);
            this.label2.TabIndex = 14;
            this.label2.Text = "编号";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(107, 89);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 21);
            this.textBox3.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(34, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 21);
            this.label3.TabIndex = 16;
            this.label3.Text = "编号";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(325, 89);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 21);
            this.textBox4.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(252, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 21);
            this.label4.TabIndex = 18;
            this.label4.Text = "编号";
            // 
            // insert_bt
            // 
            this.insert_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.insert_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.insert_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.insert_bt.ForeColor = System.Drawing.Color.White;
            this.insert_bt.Location = new System.Drawing.Point(504, 80);
            this.insert_bt.Name = "insert_bt";
            this.insert_bt.Size = new System.Drawing.Size(56, 25);
            this.insert_bt.TabIndex = 36;
            this.insert_bt.Text = "添加";
            this.insert_bt.UseVisualStyleBackColor = false;
            this.insert_bt.Click += new System.EventHandler(this.insert_bt_Click);
            // 
            // oleDbSelectCommand1
            // 
            this.oleDbSelectCommand1.CommandText = "SELECT   Course_Id, Name, Schedule, Classroom, Teacher_Id\r\nFROM      Course";
            this.oleDbSelectCommand1.Connection = this.connection;
            // 
            // connection
            // 
            this.connection.ConnectionString = "Provider=SQLNCLI11;Data Source=(local);Integrated Security=SSPI;Initial Catalog=T" +
    "eaching_management_system";
            this.connection.InfoMessage += new System.Data.OleDb.OleDbInfoMessageEventHandler(this.connection_InfoMessage);
            // 
            // oleDbInsertCommand1
            // 
            this.oleDbInsertCommand1.CommandText = "INSERT INTO [Teaching_management_system].[dbo].[Course] ([Course_Id], [Name], [Sc" +
    "hedule], [Classroom], [Teacher_Id]) VALUES (?, ?, ?, ?, ?)";
            this.oleDbInsertCommand1.Connection = this.connection;
            this.oleDbInsertCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Course_Id", System.Data.OleDb.OleDbType.VarChar, 0, "Course_Id"),
            new System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarChar, 0, "Name"),
            new System.Data.OleDb.OleDbParameter("Schedule", System.Data.OleDb.OleDbType.VarChar, 0, "Schedule"),
            new System.Data.OleDb.OleDbParameter("Classroom", System.Data.OleDb.OleDbType.VarChar, 0, "Classroom"),
            new System.Data.OleDb.OleDbParameter("Teacher_Id", System.Data.OleDb.OleDbType.VarChar, 0, "Teacher_Id")});
            // 
            // oleDbUpdateCommand1
            // 
            this.oleDbUpdateCommand1.CommandText = resources.GetString("oleDbUpdateCommand1.CommandText");
            this.oleDbUpdateCommand1.Connection = this.connection;
            this.oleDbUpdateCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Course_Id", System.Data.OleDb.OleDbType.VarChar, 0, "Course_Id"),
            new System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarChar, 0, "Name"),
            new System.Data.OleDb.OleDbParameter("Schedule", System.Data.OleDb.OleDbType.VarChar, 0, "Schedule"),
            new System.Data.OleDb.OleDbParameter("Classroom", System.Data.OleDb.OleDbType.VarChar, 0, "Classroom"),
            new System.Data.OleDb.OleDbParameter("Teacher_Id", System.Data.OleDb.OleDbType.VarChar, 0, "Teacher_Id"),
            new System.Data.OleDb.OleDbParameter("Original_Course_Id", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Course_Id", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Name", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Schedule", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Schedule", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Classroom", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Classroom", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("IsNull_Teacher_Id", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "Teacher_Id", System.Data.DataRowVersion.Original, true, null),
            new System.Data.OleDb.OleDbParameter("Original_Teacher_Id", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Teacher_Id", System.Data.DataRowVersion.Original, null)});
            // 
            // oleDbDeleteCommand1
            // 
            this.oleDbDeleteCommand1.CommandText = resources.GetString("oleDbDeleteCommand1.CommandText");
            this.oleDbDeleteCommand1.Connection = this.connection;
            this.oleDbDeleteCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_Course_Id", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Course_Id", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Name", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Schedule", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Schedule", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Classroom", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Classroom", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("IsNull_Teacher_Id", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, ((byte)(0)), ((byte)(0)), "Teacher_Id", System.Data.DataRowVersion.Original, true, null),
            new System.Data.OleDb.OleDbParameter("Original_Teacher_Id", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Teacher_Id", System.Data.DataRowVersion.Original, null)});
            // 
            // adapter
            // 
            this.adapter.DeleteCommand = this.oleDbDeleteCommand1;
            this.adapter.InsertCommand = this.oleDbInsertCommand1;
            this.adapter.SelectCommand = this.oleDbSelectCommand1;
            this.adapter.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "Course", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Course_Id", "Course_Id"),
                        new System.Data.Common.DataColumnMapping("Name", "Name"),
                        new System.Data.Common.DataColumnMapping("Schedule", "Schedule"),
                        new System.Data.Common.DataColumnMapping("Classroom", "Classroom"),
                        new System.Data.Common.DataColumnMapping("Teacher_Id", "Teacher_Id")})});
            this.adapter.UpdateCommand = this.oleDbUpdateCommand1;
            // 
            // dataGrid1
            // 
            this.dataGrid1.AlternatingBackColor = System.Drawing.Color.OldLace;
            this.dataGrid1.BackColor = System.Drawing.Color.OldLace;
            this.dataGrid1.BackgroundColor = System.Drawing.Color.Tan;
            this.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGrid1.CaptionBackColor = System.Drawing.Color.SaddleBrown;
            this.dataGrid1.CaptionForeColor = System.Drawing.Color.OldLace;
            this.dataGrid1.DataMember = "Course";
            this.dataGrid1.DataSource = this.dataSet1;
            this.dataGrid1.FlatMode = true;
            this.dataGrid1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dataGrid1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.dataGrid1.GridLineColor = System.Drawing.Color.Tan;
            this.dataGrid1.HeaderBackColor = System.Drawing.Color.Wheat;
            this.dataGrid1.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.HeaderForeColor = System.Drawing.Color.SaddleBrown;
            this.dataGrid1.LinkColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.Location = new System.Drawing.Point(25, 122);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.OldLace;
            this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateGray;
            this.dataGrid1.PreferredColumnWidth = 100;
            this.dataGrid1.PreferredRowHeight = 20;
            this.dataGrid1.SelectionBackColor = System.Drawing.Color.SlateGray;
            this.dataGrid1.SelectionForeColor = System.Drawing.Color.White;
            this.dataGrid1.Size = new System.Drawing.Size(543, 155);
            this.dataGrid1.TabIndex = 37;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "dataSet";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // delete_bt
            // 
            this.delete_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.delete_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.delete_bt.ForeColor = System.Drawing.Color.White;
            this.delete_bt.Location = new System.Drawing.Point(446, 297);
            this.delete_bt.Name = "delete_bt";
            this.delete_bt.Size = new System.Drawing.Size(56, 25);
            this.delete_bt.TabIndex = 39;
            this.delete_bt.Text = "删除";
            this.delete_bt.UseVisualStyleBackColor = false;
            this.delete_bt.Click += new System.EventHandler(this.delete_bt_Click);
            // 
            // save_bt
            // 
            this.save_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.save_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.save_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.save_bt.ForeColor = System.Drawing.Color.White;
            this.save_bt.Location = new System.Drawing.Point(293, 297);
            this.save_bt.Name = "save_bt";
            this.save_bt.Size = new System.Drawing.Size(56, 25);
            this.save_bt.TabIndex = 38;
            this.save_bt.Text = "提交";
            this.save_bt.UseVisualStyleBackColor = false;
            this.save_bt.Click += new System.EventHandler(this.save_bt_Click);
            // 
            // AddStu_bt
            // 
            this.AddStu_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.AddStu_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddStu_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AddStu_bt.ForeColor = System.Drawing.Color.White;
            this.AddStu_bt.Location = new System.Drawing.Point(140, 297);
            this.AddStu_bt.Name = "AddStu_bt";
            this.AddStu_bt.Size = new System.Drawing.Size(65, 25);
            this.AddStu_bt.TabIndex = 40;
            this.AddStu_bt.Text = "添加学生";
            this.AddStu_bt.UseVisualStyleBackColor = false;
            this.AddStu_bt.Click += new System.EventHandler(this.AddStu_bt_Click);
            // 
            // AddHowork_bt
            // 
            this.AddHowork_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.AddHowork_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddHowork_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AddHowork_bt.ForeColor = System.Drawing.Color.White;
            this.AddHowork_bt.Location = new System.Drawing.Point(38, 297);
            this.AddHowork_bt.Name = "AddHowork_bt";
            this.AddHowork_bt.Size = new System.Drawing.Size(65, 25);
            this.AddHowork_bt.TabIndex = 41;
            this.AddHowork_bt.Text = "添加作业";
            this.AddHowork_bt.UseVisualStyleBackColor = false;
            this.AddHowork_bt.Click += new System.EventHandler(this.AddHowork_bt_Click);
            // 
            // UI_CommonWindow_ForTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(594, 360);
            this.Controls.Add(this.AddHowork_bt);
            this.Controls.Add(this.AddStu_bt);
            this.Controls.Add(this.delete_bt);
            this.Controls.Add(this.save_bt);
            this.Controls.Add(this.dataGrid1);
            this.Controls.Add(this.insert_bt);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.课程管理);
            this.Name = "UI_CommonWindow_ForTeacher";
            this.Text = "UI_CommonWindow_ForTeacher";
            this.Load += new System.EventHandler(this.UI_CommonWindow_ForTeacher_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label 课程管理;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button insert_bt;
        private System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
        private System.Data.OleDb.OleDbCommand oleDbInsertCommand1;
        private System.Data.OleDb.OleDbCommand oleDbUpdateCommand1;
        private System.Data.OleDb.OleDbCommand oleDbDeleteCommand1;
        private System.Data.OleDb.OleDbDataAdapter adapter;
        private System.Data.OleDb.OleDbConnection connection;
        private System.Windows.Forms.DataGrid dataGrid1;
        private System.Windows.Forms.Button delete_bt;
        private System.Windows.Forms.Button save_bt;
        private dataSet dataSet1;
        private System.Windows.Forms.Button AddStu_bt;
        private System.Windows.Forms.Button AddHowork_bt;
    }
}