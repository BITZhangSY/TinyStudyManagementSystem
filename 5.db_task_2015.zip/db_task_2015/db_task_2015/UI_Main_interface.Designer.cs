﻿namespace db_task_2015
{
    partial class UI_Main_interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.type_label = new System.Windows.Forms.Label();
            this.name_label = new System.Windows.Forms.Label();
            this.account_label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tab_bt_1 = new System.Windows.Forms.Button();
            this.tab_bt_5 = new System.Windows.Forms.Button();
            this.tab_bt_4 = new System.Windows.Forms.Button();
            this.tab_bt_3 = new System.Windows.Forms.Button();
            this.tab_bt_2 = new System.Windows.Forms.Button();
            this.quit_bt = new System.Windows.Forms.Button();
            this.tab_bt_6 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // type_label
            // 
            this.type_label.AutoSize = true;
            this.type_label.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.type_label.ForeColor = System.Drawing.SystemColors.InfoText;
            this.type_label.Location = new System.Drawing.Point(216, 44);
            this.type_label.Name = "type_label";
            this.type_label.Size = new System.Drawing.Size(65, 20);
            this.type_label.TabIndex = 27;
            this.type_label.Text = "用户类型";
            // 
            // name_label
            // 
            this.name_label.AutoSize = true;
            this.name_label.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.name_label.ForeColor = System.Drawing.SystemColors.InfoText;
            this.name_label.Location = new System.Drawing.Point(116, 44);
            this.name_label.Name = "name_label";
            this.name_label.Size = new System.Drawing.Size(37, 20);
            this.name_label.TabIndex = 26;
            this.name_label.Text = "名称";
            // 
            // account_label
            // 
            this.account_label.AutoSize = true;
            this.account_label.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.account_label.ForeColor = System.Drawing.SystemColors.InfoText;
            this.account_label.Location = new System.Drawing.Point(19, 44);
            this.account_label.Name = "account_label";
            this.account_label.Size = new System.Drawing.Size(37, 20);
            this.account_label.TabIndex = 25;
            this.account_label.Text = "账号";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Linen;
            this.label4.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Location = new System.Drawing.Point(12, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 21);
            this.label4.TabIndex = 24;
            this.label4.Text = "教学管理系统欢迎您";
            // 
            // tab_bt_1
            // 
            this.tab_bt_1.BackColor = System.Drawing.Color.SteelBlue;
            this.tab_bt_1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tab_bt_1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab_bt_1.ForeColor = System.Drawing.Color.White;
            this.tab_bt_1.Location = new System.Drawing.Point(16, 81);
            this.tab_bt_1.Name = "tab_bt_1";
            this.tab_bt_1.Size = new System.Drawing.Size(97, 35);
            this.tab_bt_1.TabIndex = 28;
            this.tab_bt_1.Text = "取消";
            this.tab_bt_1.UseVisualStyleBackColor = false;
            this.tab_bt_1.Click += new System.EventHandler(this.tab_bt_1_Click);
            // 
            // tab_bt_5
            // 
            this.tab_bt_5.BackColor = System.Drawing.Color.SteelBlue;
            this.tab_bt_5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tab_bt_5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab_bt_5.ForeColor = System.Drawing.Color.White;
            this.tab_bt_5.Location = new System.Drawing.Point(523, 81);
            this.tab_bt_5.Name = "tab_bt_5";
            this.tab_bt_5.Size = new System.Drawing.Size(97, 35);
            this.tab_bt_5.TabIndex = 30;
            this.tab_bt_5.Text = "取消";
            this.tab_bt_5.UseVisualStyleBackColor = false;
            this.tab_bt_5.Click += new System.EventHandler(this.tab_bt_5_Click);
            // 
            // tab_bt_4
            // 
            this.tab_bt_4.BackColor = System.Drawing.Color.SteelBlue;
            this.tab_bt_4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tab_bt_4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab_bt_4.ForeColor = System.Drawing.Color.White;
            this.tab_bt_4.Location = new System.Drawing.Point(304, 81);
            this.tab_bt_4.Name = "tab_bt_4";
            this.tab_bt_4.Size = new System.Drawing.Size(97, 35);
            this.tab_bt_4.TabIndex = 31;
            this.tab_bt_4.Text = "取消";
            this.tab_bt_4.UseVisualStyleBackColor = false;
            this.tab_bt_4.Click += new System.EventHandler(this.tab_bt_4_Click);
            // 
            // tab_bt_3
            // 
            this.tab_bt_3.BackColor = System.Drawing.Color.SteelBlue;
            this.tab_bt_3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tab_bt_3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab_bt_3.ForeColor = System.Drawing.Color.White;
            this.tab_bt_3.Location = new System.Drawing.Point(208, 81);
            this.tab_bt_3.Name = "tab_bt_3";
            this.tab_bt_3.Size = new System.Drawing.Size(97, 35);
            this.tab_bt_3.TabIndex = 32;
            this.tab_bt_3.Text = "取消";
            this.tab_bt_3.UseVisualStyleBackColor = false;
            this.tab_bt_3.Click += new System.EventHandler(this.tab_bt_3_Click);
            // 
            // tab_bt_2
            // 
            this.tab_bt_2.BackColor = System.Drawing.Color.SteelBlue;
            this.tab_bt_2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tab_bt_2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab_bt_2.ForeColor = System.Drawing.Color.White;
            this.tab_bt_2.Location = new System.Drawing.Point(112, 81);
            this.tab_bt_2.Name = "tab_bt_2";
            this.tab_bt_2.Size = new System.Drawing.Size(97, 35);
            this.tab_bt_2.TabIndex = 33;
            this.tab_bt_2.Text = "取消";
            this.tab_bt_2.UseVisualStyleBackColor = false;
            this.tab_bt_2.Click += new System.EventHandler(this.tab_bt_2_Click);
            // 
            // quit_bt
            // 
            this.quit_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.quit_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.quit_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.quit_bt.ForeColor = System.Drawing.Color.White;
            this.quit_bt.Location = new System.Drawing.Point(566, 12);
            this.quit_bt.Name = "quit_bt";
            this.quit_bt.Size = new System.Drawing.Size(56, 25);
            this.quit_bt.TabIndex = 34;
            this.quit_bt.Text = "退出";
            this.quit_bt.UseVisualStyleBackColor = false;
            this.quit_bt.Click += new System.EventHandler(this.quit_bt_Click);
            // 
            // tab_bt_6
            // 
            this.tab_bt_6.BackColor = System.Drawing.Color.SteelBlue;
            this.tab_bt_6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tab_bt_6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tab_bt_6.ForeColor = System.Drawing.Color.White;
            this.tab_bt_6.Location = new System.Drawing.Point(400, 81);
            this.tab_bt_6.Name = "tab_bt_6";
            this.tab_bt_6.Size = new System.Drawing.Size(97, 35);
            this.tab_bt_6.TabIndex = 35;
            this.tab_bt_6.Text = "取消";
            this.tab_bt_6.UseVisualStyleBackColor = false;
            this.tab_bt_6.Click += new System.EventHandler(this.tab_bt_6_Click);
            // 
            // UI_Main_interface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(634, 380);
            this.Controls.Add(this.tab_bt_6);
            this.Controls.Add(this.quit_bt);
            this.Controls.Add(this.tab_bt_2);
            this.Controls.Add(this.tab_bt_3);
            this.Controls.Add(this.tab_bt_4);
            this.Controls.Add(this.tab_bt_5);
            this.Controls.Add(this.tab_bt_1);
            this.Controls.Add(this.type_label);
            this.Controls.Add(this.name_label);
            this.Controls.Add(this.account_label);
            this.Controls.Add(this.label4);
            this.Name = "UI_Main_interface";
            this.Text = "UI_Main_interface";
            this.Load += new System.EventHandler(this.UI_Main_interface_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label type_label;
        private System.Windows.Forms.Label name_label;
        private System.Windows.Forms.Label account_label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button tab_bt_1;
        private System.Windows.Forms.Button tab_bt_5;
        private System.Windows.Forms.Button tab_bt_4;
        private System.Windows.Forms.Button tab_bt_3;
        private System.Windows.Forms.Button tab_bt_2;
        private System.Windows.Forms.Button quit_bt;
        private System.Windows.Forms.Button tab_bt_6;
    }
}