﻿namespace db_task_2015
{
    partial class UI_AddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StudentId_textBox = new System.Windows.Forms.TextBox();
            this.StudentId_label = new System.Windows.Forms.Label();
            this.课程管理 = new System.Windows.Forms.Label();
            this.AddStu_bt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // StudentId_textBox
            // 
            this.StudentId_textBox.Location = new System.Drawing.Point(112, 56);
            this.StudentId_textBox.Name = "StudentId_textBox";
            this.StudentId_textBox.Size = new System.Drawing.Size(100, 21);
            this.StudentId_textBox.TabIndex = 15;
            // 
            // StudentId_label
            // 
            this.StudentId_label.AutoSize = true;
            this.StudentId_label.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.StudentId_label.Location = new System.Drawing.Point(39, 55);
            this.StudentId_label.Name = "StudentId_label";
            this.StudentId_label.Size = new System.Drawing.Size(42, 21);
            this.StudentId_label.TabIndex = 14;
            this.StudentId_label.Text = "编号";
            // 
            // 课程管理
            // 
            this.课程管理.AutoSize = true;
            this.课程管理.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.课程管理.Location = new System.Drawing.Point(12, 9);
            this.课程管理.Name = "课程管理";
            this.课程管理.Size = new System.Drawing.Size(88, 26);
            this.课程管理.TabIndex = 16;
            this.课程管理.Text = "添加学生";
            // 
            // AddStu_bt
            // 
            this.AddStu_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.AddStu_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddStu_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AddStu_bt.ForeColor = System.Drawing.Color.White;
            this.AddStu_bt.Location = new System.Drawing.Point(183, 97);
            this.AddStu_bt.Name = "AddStu_bt";
            this.AddStu_bt.Size = new System.Drawing.Size(59, 25);
            this.AddStu_bt.TabIndex = 41;
            this.AddStu_bt.Text = "添加";
            this.AddStu_bt.UseVisualStyleBackColor = false;
            this.AddStu_bt.Click += new System.EventHandler(this.AddStu_bt_Click);
            // 
            // UI_AddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(302, 157);
            this.Controls.Add(this.AddStu_bt);
            this.Controls.Add(this.课程管理);
            this.Controls.Add(this.StudentId_textBox);
            this.Controls.Add(this.StudentId_label);
            this.Name = "UI_AddStudent";
            this.Text = "UI_AddStudent";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox StudentId_textBox;
        private System.Windows.Forms.Label StudentId_label;
        private System.Windows.Forms.Label 课程管理;
        private System.Windows.Forms.Button AddStu_bt;
    }
}