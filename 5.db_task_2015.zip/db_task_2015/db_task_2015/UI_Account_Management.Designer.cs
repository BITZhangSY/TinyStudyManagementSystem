﻿namespace db_task_2015
{
    partial class UI_Account_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UI_Account_Management));
            this.label1 = new System.Windows.Forms.Label();
            this.id_textBox = new System.Windows.Forms.TextBox();
            this.pass_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.type_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.name_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.account_textBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.insert_AccountInfo_bt = new System.Windows.Forms.Button();
            this.save_bt = new System.Windows.Forms.Button();
            this.delete_bt = new System.Windows.Forms.Button();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.dataSet1 = new db_task_2015.dataSet();
            this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
            this.connection = new System.Data.OleDb.OleDbConnection();
            this.oleDbInsertCommand1 = new System.Data.OleDb.OleDbCommand();
            this.oleDbUpdateCommand1 = new System.Data.OleDb.OleDbCommand();
            this.oleDbDeleteCommand1 = new System.Data.OleDb.OleDbCommand();
            this.adapter = new System.Data.OleDb.OleDbDataAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(23, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "编号";
            // 
            // id_textBox
            // 
            this.id_textBox.Location = new System.Drawing.Point(96, 49);
            this.id_textBox.Name = "id_textBox";
            this.id_textBox.Size = new System.Drawing.Size(100, 21);
            this.id_textBox.TabIndex = 1;
            // 
            // pass_textBox
            // 
            this.pass_textBox.Location = new System.Drawing.Point(512, 49);
            this.pass_textBox.Name = "pass_textBox";
            this.pass_textBox.Size = new System.Drawing.Size(100, 21);
            this.pass_textBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(439, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "密码";
            // 
            // type_textBox
            // 
            this.type_textBox.Location = new System.Drawing.Point(305, 92);
            this.type_textBox.Name = "type_textBox";
            this.type_textBox.Size = new System.Drawing.Size(100, 21);
            this.type_textBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(232, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 21);
            this.label3.TabIndex = 4;
            this.label3.Text = "类型";
            // 
            // name_textBox
            // 
            this.name_textBox.Location = new System.Drawing.Point(96, 91);
            this.name_textBox.Name = "name_textBox";
            this.name_textBox.Size = new System.Drawing.Size(100, 21);
            this.name_textBox.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(23, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "名称";
            // 
            // account_textBox
            // 
            this.account_textBox.Location = new System.Drawing.Point(305, 50);
            this.account_textBox.Name = "account_textBox";
            this.account_textBox.Size = new System.Drawing.Size(100, 21);
            this.account_textBox.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(232, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 21);
            this.label5.TabIndex = 8;
            this.label5.Text = "账号";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(12, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 26);
            this.label6.TabIndex = 10;
            this.label6.Text = "账户管理";
            // 
            // insert_AccountInfo_bt
            // 
            this.insert_AccountInfo_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.insert_AccountInfo_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.insert_AccountInfo_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.insert_AccountInfo_bt.ForeColor = System.Drawing.Color.White;
            this.insert_AccountInfo_bt.Location = new System.Drawing.Point(556, 92);
            this.insert_AccountInfo_bt.Name = "insert_AccountInfo_bt";
            this.insert_AccountInfo_bt.Size = new System.Drawing.Size(56, 25);
            this.insert_AccountInfo_bt.TabIndex = 35;
            this.insert_AccountInfo_bt.Text = "添加";
            this.insert_AccountInfo_bt.UseVisualStyleBackColor = false;
            this.insert_AccountInfo_bt.Click += new System.EventHandler(this.insert_AccountInfo_bt_Click);
            // 
            // save_bt
            // 
            this.save_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.save_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.save_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.save_bt.ForeColor = System.Drawing.Color.White;
            this.save_bt.Location = new System.Drawing.Point(305, 325);
            this.save_bt.Name = "save_bt";
            this.save_bt.Size = new System.Drawing.Size(56, 25);
            this.save_bt.TabIndex = 36;
            this.save_bt.Text = "提交";
            this.save_bt.UseVisualStyleBackColor = false;
            this.save_bt.Click += new System.EventHandler(this.save_bt_Click);
            // 
            // delete_bt
            // 
            this.delete_bt.BackColor = System.Drawing.Color.LightSeaGreen;
            this.delete_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_bt.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.delete_bt.ForeColor = System.Drawing.Color.White;
            this.delete_bt.Location = new System.Drawing.Point(458, 325);
            this.delete_bt.Name = "delete_bt";
            this.delete_bt.Size = new System.Drawing.Size(56, 25);
            this.delete_bt.TabIndex = 37;
            this.delete_bt.Text = "删除";
            this.delete_bt.UseVisualStyleBackColor = false;
            this.delete_bt.Click += new System.EventHandler(this.delete_bt_Click);
            // 
            // dataGrid1
            // 
            this.dataGrid1.AlternatingBackColor = System.Drawing.Color.OldLace;
            this.dataGrid1.BackColor = System.Drawing.Color.OldLace;
            this.dataGrid1.BackgroundColor = System.Drawing.Color.Tan;
            this.dataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGrid1.CaptionBackColor = System.Drawing.Color.SaddleBrown;
            this.dataGrid1.CaptionForeColor = System.Drawing.Color.OldLace;
            this.dataGrid1.DataMember = "Stuff";
            this.dataGrid1.DataSource = this.dataSet1;
            this.dataGrid1.FlatMode = true;
            this.dataGrid1.Font = new System.Drawing.Font("Tahoma", 8F);
            this.dataGrid1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.dataGrid1.GridLineColor = System.Drawing.Color.Tan;
            this.dataGrid1.HeaderBackColor = System.Drawing.Color.Wheat;
            this.dataGrid1.HeaderFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.dataGrid1.HeaderForeColor = System.Drawing.Color.SaddleBrown;
            this.dataGrid1.LinkColor = System.Drawing.Color.DarkSlateBlue;
            this.dataGrid1.Location = new System.Drawing.Point(42, 151);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ParentRowsBackColor = System.Drawing.Color.OldLace;
            this.dataGrid1.ParentRowsForeColor = System.Drawing.Color.DarkSlateGray;
            this.dataGrid1.PreferredColumnWidth = 100;
            this.dataGrid1.PreferredRowHeight = 20;
            this.dataGrid1.SelectionBackColor = System.Drawing.Color.SlateGray;
            this.dataGrid1.SelectionForeColor = System.Drawing.Color.White;
            this.dataGrid1.Size = new System.Drawing.Size(538, 156);
            this.dataGrid1.TabIndex = 38;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "dataSet";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // oleDbSelectCommand1
            // 
            this.oleDbSelectCommand1.CommandText = "select * from Stuff";
            this.oleDbSelectCommand1.Connection = this.connection;
            // 
            // connection
            // 
            this.connection.ConnectionString = "Provider=SQLNCLI11;Data Source=(local);Integrated Security=SSPI;Initial Catalog=T" +
    "eaching_management_system";
            // 
            // oleDbInsertCommand1
            // 
            this.oleDbInsertCommand1.CommandText = "INSERT INTO [Teaching_management_system].[dbo].[Stuff] ([Stuff_Id], [Account], [P" +
    "assword], [Type], [Name]) VALUES (?, ?, ?, ?, ?)";
            this.oleDbInsertCommand1.Connection = this.connection;
            this.oleDbInsertCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Stuff_Id", System.Data.OleDb.OleDbType.VarChar, 0, "Stuff_Id"),
            new System.Data.OleDb.OleDbParameter("Account", System.Data.OleDb.OleDbType.VarChar, 0, "Account"),
            new System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 0, "Password"),
            new System.Data.OleDb.OleDbParameter("Type", System.Data.OleDb.OleDbType.VarChar, 0, "Type"),
            new System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarChar, 0, "Name")});
            // 
            // oleDbUpdateCommand1
            // 
            this.oleDbUpdateCommand1.CommandText = resources.GetString("oleDbUpdateCommand1.CommandText");
            this.oleDbUpdateCommand1.Connection = this.connection;
            this.oleDbUpdateCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Stuff_Id", System.Data.OleDb.OleDbType.VarChar, 0, "Stuff_Id"),
            new System.Data.OleDb.OleDbParameter("Account", System.Data.OleDb.OleDbType.VarChar, 0, "Account"),
            new System.Data.OleDb.OleDbParameter("Password", System.Data.OleDb.OleDbType.VarChar, 0, "Password"),
            new System.Data.OleDb.OleDbParameter("Type", System.Data.OleDb.OleDbType.VarChar, 0, "Type"),
            new System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarChar, 0, "Name"),
            new System.Data.OleDb.OleDbParameter("Original_Stuff_Id", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Stuff_Id", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Account", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Account", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Password", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Type", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Type", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Name", System.Data.DataRowVersion.Original, null)});
            // 
            // oleDbDeleteCommand1
            // 
            this.oleDbDeleteCommand1.CommandText = "DELETE FROM [Teaching_management_system].[dbo].[Stuff] WHERE (([Stuff_Id] = ?) AN" +
    "D ([Account] = ?) AND ([Password] = ?) AND ([Type] = ?) AND ([Name] = ?))";
            this.oleDbDeleteCommand1.Connection = this.connection;
            this.oleDbDeleteCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_Stuff_Id", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Stuff_Id", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Account", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Account", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Password", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Password", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Type", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Type", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "Name", System.Data.DataRowVersion.Original, null)});
            // 
            // adapter
            // 
            this.adapter.DeleteCommand = this.oleDbDeleteCommand1;
            this.adapter.InsertCommand = this.oleDbInsertCommand1;
            this.adapter.SelectCommand = this.oleDbSelectCommand1;
            this.adapter.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "Stuff", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Stuff_Id", "Stuff_Id"),
                        new System.Data.Common.DataColumnMapping("Account", "Account"),
                        new System.Data.Common.DataColumnMapping("Password", "Password"),
                        new System.Data.Common.DataColumnMapping("Type", "Type"),
                        new System.Data.Common.DataColumnMapping("Name", "Name")})});
            this.adapter.UpdateCommand = this.oleDbUpdateCommand1;
            // 
            // UI_Account_Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(635, 375);
            this.Controls.Add(this.dataGrid1);
            this.Controls.Add(this.delete_bt);
            this.Controls.Add(this.save_bt);
            this.Controls.Add(this.insert_AccountInfo_bt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.account_textBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.name_textBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.type_textBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pass_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.id_textBox);
            this.Controls.Add(this.label1);
            this.Name = "UI_Account_Management";
            this.Text = "UI_Account_Management";
            this.Load += new System.EventHandler(this.UI_Account_Management_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox id_textBox;
        private System.Windows.Forms.TextBox pass_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox type_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox name_textBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox account_textBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button insert_AccountInfo_bt;
        private System.Windows.Forms.Button save_bt;
        private System.Windows.Forms.Button delete_bt;
        private System.Windows.Forms.DataGrid dataGrid1;
        private dataSet dataSet1;
        private System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
        private System.Data.OleDb.OleDbConnection connection;
        private System.Data.OleDb.OleDbCommand oleDbInsertCommand1;
        private System.Data.OleDb.OleDbCommand oleDbUpdateCommand1;
        private System.Data.OleDb.OleDbCommand oleDbDeleteCommand1;
        private System.Data.OleDb.OleDbDataAdapter adapter;
    }
}