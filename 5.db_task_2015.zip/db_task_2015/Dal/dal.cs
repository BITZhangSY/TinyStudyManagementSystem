﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.OleDb;

using Entity;
namespace Dal
{
    public class dal
    {
        public void sql_NonQuery(String sql)
        {
            dal_OleDb.myExecuteNon(sql);
        }
        public Account sql_Query(String sql)
        {
            Account account = dal_OleDb.myQuery(sql);
            return account;
        }
        public bool sql_update_AccountInfo(String sql, String new_password)
        {
            bool if_success = dal_OleDb.update_AccountInfo(sql, new_password);
            return if_success;
        }
        public bool sql_add_Student(String sql)
        {
            bool if_success = dal_OleDb.add_Student(sql);
            return if_success;
        }        
        public bool sql_add_Homework(String sql)
        {
            bool if_success = dal_OleDb.add_Homework(sql);
            return if_success;
        }

        public List<Inform> sql_get_Inform(String sql)
        {
            return dal_OleDb.Inform_query(sql);
        }

        public List<Course> sql_get_Course(String sql)
        {
            return dal_OleDb.get_Course(sql);
        }

        public List<Examination> sql_get_Exam(String sql)
        {
            return dal_OleDb.get_Exam(sql);
        }

        public List<Homework> sql_get_Homework(String sql)
        {
            return dal_OleDb.get_Homework(sql);
        }

        public bool sql_insert_Inform(String sql)
        {
            bool if_success = dal_OleDb.insert_Inform(sql);
            return if_success;
        }
    }
}
