﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.OleDb;

using Entity;

namespace Dal
{
    public class dal_OleDb
    {
        
        public static void myExecuteNon(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        
        public static Account myQuery(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();

            Account info_account = new Account();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    info_account.stuff_id = (String)reader[0];
                    info_account.account = (String)reader[1];
                    info_account.name = (String)reader[4];
                    info_account.type = (String)reader[3];
                }
            }
            else
            {
                info_account = null;
            }
            reader.Close();
            conn.Close();
            return info_account;        
        }

        public static List<Inform> Inform_query(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();

            List<Inform> list = new List<Inform>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Inform inform = new Inform();
                    inform.info_id = (String)reader[0];
                    inform.content = (String)reader[2];
                    inform.type = (String)reader[3];
                    inform.title = (String)reader[1];

                    list.Add(inform);
                }
            }
            else
            {
                list = null;
            }
            return list;
        }

        public static List<Course> get_Course(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();

            List<Course> list = new List<Course>();
            if (reader.HasRows)
            {
                
                while (reader.Read())
                {
                    Course course = new Course();
                    course.Course_Id = (String)reader[0];
                    course.Name = (String)reader[1];
                    course.Schedule = (String)reader[2];
                    course.Classroom = (String)reader[3];
                    course.Teacher_Id = (String)reader[4];

                    String sql_forSelect = "select Name from Stuff where Stuff_Id='" + course.Teacher_Id + "'";
                    course.Teacher_Name = sql_selectOneString(sql_forSelect);

                    list.Add(course);
                }
            }
            else
            {
                list = null;
            }
            return list;
        }

        public static List<Examination> get_Exam(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();

            List<Examination> list = new List<Examination>();
            if (reader.HasRows)
            {

                while (reader.Read())
                {
                    Examination exam = new Examination();
                    exam.Course_Id = (String)reader[0];
                    exam.Date = reader[2].ToString();
                    exam.Score = reader[3].ToString();
                    String sql_forSelect = "select Name from Course where Course_Id='" + exam.Course_Id + "'";
                    exam.Course_Name = sql_selectOneString(sql_forSelect);

                    list.Add(exam);
                }
            }
            else
            {
                list = null;
            }
            return list;
        }

        public static List<Homework> get_Homework(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();

            List<Homework> list = new List<Homework>();
            if (reader.HasRows)
            {

                while (reader.Read())
                {
                    Homework homework = new Homework();
                    homework.homework_id = (String)reader[0];
                    homework.content = (String)reader[1];
                    homework.date = (String)reader[2].ToString();
                    String course_id = (String)reader[3];
                    String teacher_id = (String)reader[4];

                    String sql_forSelect = "select Name from Course where Course_Id='" + course_id + "'";
                    homework.course_name = sql_selectOneString(sql_forSelect);
                    sql_forSelect = "select Name from Stuff where Stuff_Id='" + teacher_id + "'";
                    homework.teacher_name = sql_selectOneString(sql_forSelect);

                    list.Add(homework);
                }
            }
            else
            {
                list = null;
            }
            return list;
        }

        public static String sql_selectOneString(String sql)
        {
            String target = "";
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();
            OleDbDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    target = (String)reader[0];
                }
            }
            return target;
        }

        public static bool update_AccountInfo(String sql, String new_password)
        {
            return sql_insert(sql);
        }
        public static bool insert_Inform(String sql)
        {
            return sql_insert(sql);
        }
        public static bool add_Student(String sql)
        {
            return sql_insert(sql);
        }
        public static bool add_Homework(String sql)
        {
            return sql_insert(sql);
        }

        public static bool sql_insert(String sql)
        {
            OleDbConnection conn = initial();
            OleDbCommand cmd = new OleDbCommand(sql, conn);

            conn.Open();

            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                conn.Close();            
            }
        }

        private static OleDbConnection initial()
        {
            String conn_str = "Provider=SQLNCLI11;Data Source=(local);Integrated Security=SSPI;Initial Catalog=Teaching_management_system;";
            OleDbConnection conn = new OleDbConnection(conn_str);            

            return conn;
        }
        
    }
}
