﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Homework
    {
        public String homework_id;
        public String content;
        public String date;
        public String course_name;
        public String teacher_name;
    }
}
