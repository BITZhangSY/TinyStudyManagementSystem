﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Examination
    {
        public String Course_Id;
        public String Course_Name;
        public String Student_Id;
        public String Date;
        public String Score;
    }
}
