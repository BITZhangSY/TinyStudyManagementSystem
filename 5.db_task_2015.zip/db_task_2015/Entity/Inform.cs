﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Inform
    {
        public String title;
        public String content;
        public String type;
        public String info_id;
    }
}
