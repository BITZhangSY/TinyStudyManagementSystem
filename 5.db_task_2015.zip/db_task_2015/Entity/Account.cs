﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Account
    {
        public String stuff_id;
        public String account;
        public String password;
        public String type;
        public String name;
    }
}
