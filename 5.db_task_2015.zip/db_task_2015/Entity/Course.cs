﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Course
    {
        public String Course_Id;
        public String Name;
        public String Schedule;
        public String Classroom;
        public String Teacher_Id;
        public String Teacher_Name;
    }
}
